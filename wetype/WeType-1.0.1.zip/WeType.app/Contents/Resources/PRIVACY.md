# WeType privacy

*Last updated 2026-08-10.*

WeType reads text from every application you type in, and predicts what you might write next. It
can only do that by seeing what you write. This page says exactly what it sees, what it keeps, where
it keeps it, and how to get rid of it — in plain language, without the hedging that usually goes in
a document like this.

## The short version

**Nothing leaves your Mac.** The language model runs locally. There is no account, no server, no
analytics, and no telemetry. The app makes exactly two kinds of network request, both of which you
start yourself:

1. downloading a model you picked in Settings › Models, from the Ollama registry;
2. checking for an app update, if a maintainer has configured an update feed (see *Updates* below).

Neither request carries anything about what you type.

## What WeType reads

While it is enabled and not paused, WeType reads:

- **the focused text field** — its contents, where the caret is, its font and colour;
- **the prose around that field** — the message you are replying to, the subject line, the earlier
  lines of the note. This is what lets suggestions respond to context rather than only continuing
  your sentence. You can turn it off in Settings › General › *Use surrounding context*, and when it
  is off nothing around the field is read at all — not merely omitted from the prompt;
- **which application and window** the field belongs to, and for web fields the site's domain, so
  per-app settings and per-site rules can be applied.

### What it never reads

- **Secure fields.** Password boxes, anything macOS marks as protected content, and any field whose
  label or placeholder looks like a credential ("password", "passcode", "CVV", "one-time code").
- **Anything in an app where completion is switched off**, including password managers. The check
  happens *before* the read, so a disabled app's surroundings are never harvested.
- **Fields on blocked sites.** Banking, payments and health hosts are excluded by default, and you
  can add your own in Settings › Privacy.

## What WeType keeps

Everything below lives in `~/Library/Application Support/WeType/`, readable only by you.

| What | File | Default | Retention |
|---|---|---|---|
| Sentences you wrote, per app, used to suggest in your voice | `typing-history.json` | **On**, disclosed at first run | 90 days, configurable; an app is forgotten once its last sentence ages out |
| Words and characters saved, per day | `usage-stats.json` | On | Until you delete it |
| Placement diagnostics for debugging | `diagnostics.jsonl` | **Off** | Capped at 1 MB |
| Screenshots around the caret, for pixel-verifying placement | `shots/` | **Off** | 7 days, capped at 50 MB |
| Crash reports (the crash only — never your text) | `crashes/` | **Off** | Until you delete them |

Your settings live in the `com.wetype.app` preferences domain.

The typing history stores at most 40 sentences per app, each at most 240 characters, and only
*completed* sentences — never the fragment you are in the middle of. Code fields are never used for
style. You can read every stored sentence in Settings › Personalization › *Show what WeType has
learned*, and delete them one at a time, one app at a time, or all at once.

## Deleting everything

**Settings › Privacy › Delete All WeType Data** removes every file listed above and every
setting, returning the app to a fresh-install state. Downloaded models are kept, because they are
large and contain nothing about you; delete them in Settings › Models.

To remove the app entirely:

```sh
rm -rf /Applications/WeType.app
rm -rf ~/Library/Application\ Support/WeType
defaults delete com.wetype.app
```

## Permissions, and why

- **Accessibility** — read the focused field's text and caret position, and insert accepted
  completions. There is no other API on macOS that can do either.
- **Input Monitoring** — notice the keys you type, so a suggestion can follow your typing, and
  capture the accept key. WeType sees key events for the accept keys and for ordinary
  characters; it does not record them anywhere.
- **Screen Recording** *(optional, off)* — only used by the placement-verification tooling, which is
  disabled by default. WeType works fully without it.

While WeType is running it also sets the `AXEnhancedUserInterface` accessibility flag on
Chromium- and Electron-based apps, which is the only way those expose their text fields. It restores
that flag when you switch away and when you quit.

## Insertion and your clipboard

Accepted text is inserted by putting it briefly on the clipboard and synthesising ⌘V, then restoring
what you had. Two consequences worth knowing:

- clipboard-history apps (Maccy, Raycast, Paste, Alfred) will record each accepted suggestion. If
  that bothers you, switch an app to *Type directly* in Settings › Per-App › Insertion;
- if you press ⌘C during the brief restore window, **your copy wins** — WeType checks and will
  not overwrite it.

## Updates

If the build you are running has an update feed configured, WeType checks it periodically over
HTTPS and verifies every update against a signing key before installing it. The check sends no
information about you — Sparkle's optional system-profile reporting is explicitly disabled. macOS
asks your permission before the first check. If no feed is configured, no check is ever made and the
menu says so.

## Questions

If something here doesn't match what you observe, that is a bug and worth reporting. The behaviour
described above is enforced in code at:
`SurroundingContextPolicy`, `PersonalizationStore`, `AppDataLocations`, `CrashReporter`, and
`TextInjector`.
