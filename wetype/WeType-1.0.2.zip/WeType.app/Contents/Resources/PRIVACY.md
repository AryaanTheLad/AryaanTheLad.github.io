# WeType privacy

*Last updated 2026-09-12.*

WeType reads text from every application you type in, and predicts what you might write next. It
can only do that by seeing what you write. This page says exactly what it sees, what it keeps, where
it keeps it, and how to get rid of it — in plain language, without the hedging that usually goes in
a document like this.

## The short version

**Nothing you type leaves your Mac.** The language model runs locally. There is no account, and no
server of ours ever sees a word you have written. The app makes four kinds of network request:

1. downloading a model you picked in Settings › Models, from the Ollama registry;
2. checking for an app update, and for in-app announcements (see *Updates* below);
3. validating a licence key against LemonSqueezy, after you buy one;
4. sending eight anonymous product events, which you can switch off (see *Anonymous usage* below).

None of them carries anything you have typed, and none of them carries your name, your email
address, or any identifier belonging to your Mac.

Earlier versions of this document said "no analytics and no telemetry". That stopped being true in
version 1.1, and saying so plainly is better than quietly dropping the sentence. What changed, and
exactly what it sends, is the *Anonymous usage* section below — written before you are asked to
agree to it, with the switch on the last page of first-run setup.

## What WeType reads

While it is enabled and not paused, WeType reads:

- **the focused text field** — its contents, where the caret is, its font and colour;
- **the prose around that field** — the message you are replying to, the subject line, the earlier
  lines of the note. This is what lets suggestions respond to context rather than only continuing
  your sentence. You can turn it off in Settings › General › *Use surrounding context*, and when it
  is off nothing around the field is read at all — not merely omitted from the prompt;
- **which application and window** the field belongs to, and for web fields the site's domain, so
  per-app settings and per-site rules can be applied.

### What it never reads

- **Secure fields.** Password boxes, anything macOS marks as protected content, and any field whose
  label or placeholder looks like a credential ("password", "passcode", "CVV", "one-time code").
- **Anything in an app where completion is switched off**, including password managers. The check
  happens *before* the read, so a disabled app's surroundings are never harvested.
- **Fields on blocked sites.** Banking, payments and health hosts are excluded by default, and you
  can add your own in Settings › Privacy.

## What WeType keeps

Everything below lives in `~/Library/Application Support/WeType/`, readable only by you.

| What | File | Default | Retention |
|---|---|---|---|
| Sentences you wrote, per app, used to suggest in your voice | `typing-history.json` | **On**, disclosed at first run | 90 days, configurable; an app is forgotten once its last sentence ages out |
| Words and characters saved, per day | `usage-stats.json` | On | Until you delete it |
| Placement diagnostics for debugging | `diagnostics.jsonl` | **Off** | Capped at 1 MB |
| Screenshots around the caret, for pixel-verifying placement | `shots/` | **Off** | 7 days, capped at 50 MB |
| Crash reports (the crash only — never your text) | `crashes/` | **Off** | Until you delete them |
| Product events waiting to be sent, if any | `telemetry-queue.json` | On | Deleted the moment they are sent |

Your settings live in the `com.wetype.app` preferences domain.

The typing history stores at most 40 sentences per app, each at most 240 characters, and only
*completed* sentences — never the fragment you are in the middle of. Code fields are never used for
style. You can read every stored sentence in Settings › Personalization › *Show what WeType has
learned*, and delete them one at a time, one app at a time, or all at once.

## Deleting everything

**Settings › Privacy › Delete All WeType Data** removes every file listed above and every
setting, returning the app to a fresh-install state. Downloaded models are kept, because they are
large and contain nothing about you; delete them in Settings › Models.

To remove the app entirely:

```sh
rm -rf /Applications/WeType.app
rm -rf ~/Library/Application\ Support/WeType
defaults delete com.wetype.app
defaults delete com.wetype.install
security delete-generic-password -s com.wetype.app.install
```

The last two lines remove the anonymous usage ID described below. **Settings › Privacy › Delete All
WeType Data** already does this from inside the app; they are here so that an uninstall by hand
leaves nothing either. (The trial clock is kept deliberately and is not listed: it is what stops a
reinstall handing out another free five days.)

## Permissions, and why

- **Accessibility** — read the focused field's text and caret position, and insert accepted
  completions. There is no other API on macOS that can do either.
- **Input Monitoring** — notice the keys you type, so a suggestion can follow your typing, and
  capture the accept key. WeType sees key events for the accept keys and for ordinary
  characters; it does not record them anywhere.
- **Screen Recording** *(optional, off)* — only used by the placement-verification tooling, which is
  disabled by default. WeType works fully without it.

While WeType is running it also sets the `AXEnhancedUserInterface` accessibility flag on
Chromium- and Electron-based apps, which is the only way those expose their text fields. It restores
that flag when you switch away and when you quit.

## Anonymous usage

WeType is a paid product with one developer and no funding. Without some measure of what happens
after someone downloads it, the only visible numbers are sales — which say nothing about the people
who installed it, never got a suggestion to appear, and quietly deleted it. This is the smallest
thing that answers that question.

**The identifier.** One random UUID, generated by the app on its own first run and stored in your
login Keychain. It is not your hardware serial, not your MAC address, not `IOPlatformUUID`, not a
hash of any of those, and not derived from anything another piece of software on your Mac can read.
It correlates with nothing outside this app.

**What is sent with every batch.** That UUID, the WeType version, the macOS version as major and
minor only, your language (`en`, `ur`) but never your region, and `arm64`.

**The events.** There are exactly eight, and this is all of them:

| Event | When |
|---|---|
| `install` | the first time WeType runs on this Mac |
| `launch` | at most once per day, so "did they come back" is answerable |
| `onboarding_completed` | you finish first-run setup — with whether each permission was actually granted |
| `first_acceptance` | the first suggestion you ever accept |
| `trial_limit_reached` | a trial day's 100 words are spent |
| `trial_expired` | the five-day trial ends |
| `checkout_opened` | you open a checkout page, and which screen you opened it from |
| `license_activated` | you activate a key, with a SHA-256 hash of that key |

Each carries at most two extra values, and every one of them is an integer or a word from a fixed
list (`trial`, `lifetime`, `menu`, `settings`…). **There is no free-text field anywhere in the
pipeline.** Not one. That is not a policy that could be forgotten — it is the shape of the code: the
app can only send values from a Swift enum, and the server only stores properties on an allow-list,
so sending a window title, a file path, a URL or a line of your writing would require a deliberate,
conspicuous change in two separate repositories.

**The licence-key hash** is the one thing that ties an install to a purchase, which is the only way
to know what fraction of people who install actually buy. A SHA-256 hash cannot be turned back into
a working key; the plaintext key never leaves the app by this route.

**What is never sent:** anything you type, any suggestion, any app or window name, any website, any
file path, your name, your email address, or your IP address. (The server sits behind Cloudflare,
which terminates the connection; the worker never reads or stores a connecting address.)

**Switching it off.** The switch is on the last page of first-run setup and in
**Settings › Privacy › Anonymous usage**. Turning it off stops all sending, deletes anything still
waiting in the queue, and erases the UUID — so nothing about this Mac is retained for a service you
have declined. "Delete All WeType Data" does the same.

A build with no telemetry endpoint configured does not do any of this, and the switch does not
appear at all.

## Insertion and your clipboard

Accepted text is inserted by putting it briefly on the clipboard and synthesising ⌘V, then restoring
what you had. Two consequences worth knowing:

- clipboard-history apps (Maccy, Raycast, Paste, Alfred) will record each accepted suggestion. If
  that bothers you, switch an app to *Type directly* in Settings › Per-App › Insertion;
- if you press ⌘C during the brief restore window, **your copy wins** — WeType checks and will
  not overwrite it.

## Updates

If the build you are running has an update feed configured, WeType checks it periodically over
HTTPS and verifies every update against a signing key before installing it. The check sends no
information about you — Sparkle's optional system-profile reporting is explicitly disabled. macOS
asks your permission before the first check. If no feed is configured, no check is ever made and the
menu says so.

## Questions

If something here doesn't match what you observe, that is a bug and worth reporting. The behaviour
described above is enforced in code at:
`SurroundingContextPolicy`, `PersonalizationStore`, `AppDataLocations`, `CrashReporter`,
`TextInjector`, `TelemetryClient` and `InstallIdentity`.
